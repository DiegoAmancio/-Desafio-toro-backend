"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const core_1 = require("@nestjs/core");
const helmet_1 = require("helmet");
const adapter_in_module_1 = require("./adapters/in/adapter.in.module");
let server;
async function bootstrap() {
    const app = await core_1.NestFactory.create(adapter_in_module_1.AdapterInModule);
    app.enableCors();
    if (process.env.INIT_HELMET === 'true') {
        app.use((0, helmet_1.default)({
            contentSecurityPolicy: process.env.NODE_ENV === 'production' ? undefined : false,
        }));
    }
    await app.listen(process.env.PORT, () => console.log('App running on port', process.env.PORT));
}
bootstrap();
const handler = async (event, context, callback) => {
    server = server !== null && server !== void 0 ? server : (await bootstrap());
    return server(event, context, callback);
};
exports.handler = handler;
//# sourceMappingURL=main.js.map