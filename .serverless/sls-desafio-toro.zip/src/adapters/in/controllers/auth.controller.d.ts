import { IAuthService } from '@application/in/auth.interface';
export declare class AuthController {
    private authService;
    constructor(authService: IAuthService);
    login(headers: any): Promise<any>;
}
