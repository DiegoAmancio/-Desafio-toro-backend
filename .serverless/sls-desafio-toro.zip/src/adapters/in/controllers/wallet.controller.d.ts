import { IWalletService } from '@application/in';
import { OrderPositionDTO, WalletDTO } from 'domain/dto';
import { StocksDTO } from 'domain/dto/stocks.dto';
export declare class WalletController {
    private accountService;
    constructor(accountService: IWalletService);
    getWallet(req: any): Promise<WalletDTO>;
    getTopFiveStocks(): Promise<StocksDTO[]>;
    orderStocks(orderStock: OrderPositionDTO, req: any): Promise<WalletDTO>;
}
