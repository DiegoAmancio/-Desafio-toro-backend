import { IAuthService } from '@application/in/auth.interface';
import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
export declare class UserInterceptor implements NestInterceptor {
    private authService;
    constructor(authService: IAuthService);
    private getTokenFromAuthorization;
    intercept(context: ExecutionContext, next: CallHandler): Promise<import("rxjs").Observable<any>>;
}
