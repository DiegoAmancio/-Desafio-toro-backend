"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdapterInModule = void 0;
const application_module_1 = require("@application/application.module");
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const core_1 = require("@nestjs/core");
const auth_controller_1 = require("./controllers/auth.controller");
const wallet_controller_1 = require("./controllers/wallet.controller");
const user_interceptor_1 = require("./interceptor/user.interceptor");
let AdapterInModule = class AdapterInModule {
};
AdapterInModule = __decorate([
    (0, common_1.Module)({
        imports: [config_1.ConfigModule.forRoot({ isGlobal: true }), application_module_1.ApplicationModule],
        controllers: [wallet_controller_1.WalletController, auth_controller_1.AuthController],
        providers: [
            {
                provide: core_1.APP_INTERCEPTOR,
                useClass: user_interceptor_1.UserInterceptor,
            },
        ],
    })
], AdapterInModule);
exports.AdapterInModule = AdapterInModule;
//# sourceMappingURL=adapter.in.module.js.map