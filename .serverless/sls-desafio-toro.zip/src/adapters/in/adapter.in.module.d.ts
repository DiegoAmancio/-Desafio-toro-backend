export declare class AdapterInModule {
}
