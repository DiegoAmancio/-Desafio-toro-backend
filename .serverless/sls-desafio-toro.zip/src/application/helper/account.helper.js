"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addOrder = exports.validateOrder = exports.positionsModelToEntityList = exports.getPositionsCurrentValues = exports.accumulateConsolidated = void 0;
const iex_api_1 = require("@application/api/iex.api");
const common_1 = require("@nestjs/common");
const dto_1 = require("domain/dto");
const accumulateConsolidated = (positions) => positions.reduce((count, { currentPrice }) => count + currentPrice, 0);
exports.accumulateConsolidated = accumulateConsolidated;
const getPositionsCurrentValues = async (symbols) => {
    const bdrs = await Promise.all(symbols.map(symbol => (0, iex_api_1.getBDR)(symbol)));
    return bdrs.reduce((accumulate, { latestPrice, symbol }) => {
        accumulate[symbol] = latestPrice;
        return accumulate;
    }, {});
};
exports.getPositionsCurrentValues = getPositionsCurrentValues;
const positionsModelToEntityList = (positionsModel, positionsCurrentValues) => positionsModel.map(({ symbol, amount }) => {
    const currentPrice = positionsCurrentValues[symbol];
    return new dto_1.PositionDTO(symbol, amount, currentPrice);
});
exports.positionsModelToEntityList = positionsModelToEntityList;
const validateOrder = (currentPrice, amount, checkingAccountAmount) => {
    const price = currentPrice * amount;
    if (checkingAccountAmount - price < 0) {
        throw new common_1.HttpException('Não há saldo disponível', 400);
    }
};
exports.validateOrder = validateOrder;
const addPosition = (newPosition, accountPosition) => {
    const exist = accountPosition.positions.some(position => position.symbol === newPosition.symbol);
    const updatedPositions = exist
        ? accountPosition.positions.map(position => {
            if (position.symbol === newPosition.symbol) {
                position.amount += newPosition.amount;
            }
            return position;
        })
        : accountPosition.positions.concat([newPosition]);
    return new dto_1.WalletDTO(accountPosition.checkingAccountAmount, updatedPositions);
};
const addOrder = (newPosition, accountPosition) => {
    const price = newPosition.currentPrice * newPosition.amount;
    const newAccountPosition = new dto_1.WalletDTO(accountPosition.checkingAccountAmount - price, accountPosition.positions);
    return addPosition(newPosition, newAccountPosition);
};
exports.addOrder = addOrder;
//# sourceMappingURL=account.helper.js.map