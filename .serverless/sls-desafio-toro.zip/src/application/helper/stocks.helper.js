"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getValues = void 0;
const iex_api_1 = require("@application/api/iex.api");
const common_1 = require("@nestjs/common");
const stocks_dto_1 = require("domain/dto/stocks.dto");
const validBDRResponse = (symbols, itens) => {
    if (symbols.length !== Object.keys(itens).length) {
        throw new common_1.HttpException('Ativos não encontrados', 404);
    }
};
const getValues = (symbols) => Promise.all(symbols.map(symbol => (0, iex_api_1.getBDR)(symbol))).then(itens => {
    validBDRResponse(symbols, itens);
    return itens.map(({ latestPrice, symbol }) => new stocks_dto_1.StocksDTO(symbol, latestPrice));
});
exports.getValues = getValues;
//# sourceMappingURL=stocks.helper.js.map