import { Position } from '@adapterOut/wallet/position';
import { PositionDTO, WalletDTO } from 'domain/dto';
export declare const accumulateConsolidated: (positions: PositionDTO[]) => number;
export declare const getPositionsCurrentValues: (symbols: string[]) => Promise<any>;
export declare const positionsModelToEntityList: (positionsModel: Position[], positionsCurrentValues: any) => PositionDTO[];
export declare const validateOrder: (currentPrice: number, amount: number, checkingAccountAmount: number) => void;
export declare const addOrder: (newPosition: PositionDTO, accountPosition: WalletDTO) => WalletDTO;
