import { StocksDTO } from 'domain/dto/stocks.dto';
export declare const getValues: (symbols: string[]) => Promise<StocksDTO[]>;
