import { IUserService } from '@application/in';
import { IAuthService } from '@application/in/auth.interface';
import { IGoogleService } from '@application/in/google.interface';
import { JwtService } from '@nestjs/jwt';
export declare class AuthService implements IAuthService {
    private userService;
    private googleService;
    private jwtService;
    private readonly logger;
    constructor(userService: IUserService, googleService: IGoogleService, jwtService: JwtService);
    getUserByToken(token: string): string | {
        [key: string]: any;
    };
    login(token: string): Promise<{
        name: any;
        access_token: string;
    }>;
}
