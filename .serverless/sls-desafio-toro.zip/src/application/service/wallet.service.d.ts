import { IWalletService } from '@application/in';
import { IWalletRepository } from '@application/out';
import { OrderPositionDTO, WalletDTO } from 'domain/dto';
import { StocksDTO } from 'domain/dto/stocks.dto';
export declare class WalletService implements IWalletService {
    private readonly walletRepository;
    private readonly logger;
    constructor(walletRepository: IWalletRepository);
    getTopFiveStocks(): Promise<StocksDTO[]>;
    orderStocks(orderStock: OrderPositionDTO, userId: string): Promise<WalletDTO>;
    createWallet(id: string): Promise<void>;
    getWallet(id: string): Promise<WalletDTO>;
    createAccountPosition(id: string): Promise<WalletDTO>;
}
