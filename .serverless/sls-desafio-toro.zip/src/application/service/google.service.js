"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var GoogleService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleService = void 0;
const common_1 = require("@nestjs/common");
const google_auth_library_1 = require("google-auth-library");
let GoogleService = GoogleService_1 = class GoogleService {
    constructor() {
        this.logger = new common_1.Logger(GoogleService_1.name);
        this.oAuth2Client = new google_auth_library_1.OAuth2Client(`${process.env.OAUTH_GOOGLE_ID}`, `${process.env.OAUTH_GOOGLE_SECRET}`, `${process.env.OAUTH_GOOGLE_REDIRECT_URL}`);
    }
    async getUserByToken(token) {
        this.logger.log('getUserByToken');
        const { data } = await this.oAuth2Client.transporter.request({
            method: 'GET',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Bearer ${token}`,
            },
            url: `https://www.googleapis.com/oauth2/v2/userinfo?access_token=${token}`,
        });
        return data;
    }
};
GoogleService = GoogleService_1 = __decorate([
    (0, common_1.Injectable)()
], GoogleService);
exports.GoogleService = GoogleService;
//# sourceMappingURL=google.service.js.map