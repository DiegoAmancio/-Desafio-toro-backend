import { IGoogleService } from '@application/in/google.interface';
import { TokenPayload } from 'google-auth-library';
export declare class GoogleService implements IGoogleService {
    private readonly logger;
    private readonly oAuth2Client;
    getUserByToken(token: string): Promise<TokenPayload>;
}
