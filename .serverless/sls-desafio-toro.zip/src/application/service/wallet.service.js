"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var WalletService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WalletService = void 0;
const wallet_entity_1 = require("@adapterOut/wallet/wallet.entity");
const helper_1 = require("@application/helper");
const common_1 = require("@nestjs/common");
const dto_1 = require("domain/dto");
const enums_1 = require("domain/enums");
let WalletService = WalletService_1 = class WalletService {
    constructor(walletRepository) {
        this.walletRepository = walletRepository;
        this.logger = new common_1.Logger(WalletService_1.name);
    }
    async getTopFiveStocks() {
        this.logger.log('getTopFiveStocks');
        const topFiveStocks = ['JPM', 'GOOGL', 'BRK.B', 'JNJ', 'AAPL'];
        return (0, helper_1.getValues)(topFiveStocks);
    }
    async orderStocks(orderStock, userId) {
        this.logger.log(`orderStocks ${JSON.stringify(orderStock)} ` + userId);
        const [values, dynamoWallet] = await Promise.all([
            (0, helper_1.getValues)([orderStock.symbol]),
            this.walletRepository.getWallet({
                PK: enums_1.PK.WALLET,
                SK: userId,
            }),
        ]);
        const { currentPrice } = values[0];
        const newPosition = new dto_1.PositionDTO(orderStock.symbol, orderStock.amount, currentPrice);
        const wallet = new dto_1.WalletDTO(dynamoWallet.checkingAccountAmount, dynamoWallet.positions);
        this.logger.log('validateOrder');
        (0, helper_1.validateOrder)(currentPrice, orderStock.amount, wallet.checkingAccountAmount);
        const updatedWalletDTO = (0, helper_1.addOrder)(newPosition, wallet);
        const updatedWalletDB = Object.assign(new wallet_entity_1.WalletEntity(), dynamoWallet);
        updatedWalletDB.CheckingAccountAmount =
            updatedWalletDTO.checkingAccountAmount;
        updatedWalletDB.Positions = updatedWalletDTO.positions.map(({ amount, symbol }) => ({ amount, symbol }));
        await this.walletRepository.updateWallet(updatedWalletDB);
        return updatedWalletDTO;
    }
    async createWallet(id) {
        this.logger.log(`createWallet ${id}`);
        await this.walletRepository.createWallet(id);
    }
    async getWallet(id) {
        this.logger.log(`getWallet ${id}`);
        const accountPosition = await this.walletRepository.getWallet({
            PK: enums_1.PK.WALLET,
            SK: id,
        });
        const positionsCurrentValues = await (0, helper_1.getPositionsCurrentValues)(accountPosition.positions.map(({ symbol }) => symbol));
        return new dto_1.WalletDTO(accountPosition.checkingAccountAmount, (0, helper_1.positionsModelToEntityList)(accountPosition.positions, positionsCurrentValues));
    }
    async createAccountPosition(id) {
        this.logger.log(`getWallet ${id}`);
        const accountPosition = await this.walletRepository.getWallet({
            PK: enums_1.PK.WALLET,
            SK: id,
        });
        const positionsCurrentValues = await (0, helper_1.getPositionsCurrentValues)(accountPosition.positions.map(({ symbol }) => symbol));
        return new dto_1.WalletDTO(accountPosition.checkingAccountAmount, (0, helper_1.positionsModelToEntityList)(accountPosition.positions, positionsCurrentValues));
    }
};
WalletService = WalletService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(enums_1.Providers.I_ACCOUNT_REPOSITORY)),
    __metadata("design:paramtypes", [Object])
], WalletService);
exports.WalletService = WalletService;
//# sourceMappingURL=wallet.service.js.map