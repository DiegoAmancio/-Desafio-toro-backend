import { IUserService, IWalletService } from '@application/in';
import { IUserRepository } from '@application/out';
import { CreateUserDTO, GetItemDTO } from 'domain/dto';
import { UserEntity } from '@adapterOut/user';
export declare class UserService implements IUserService {
    private readonly userRepository;
    private readonly accountService;
    private readonly logger;
    constructor(userRepository: IUserRepository, accountService: IWalletService);
    createUser(payload: CreateUserDTO): Promise<void>;
    getUser(payload: GetItemDTO): Promise<UserEntity>;
}
