export declare const getBDR: (symbol: string) => Promise<any>;
