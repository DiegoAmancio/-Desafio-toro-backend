"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBDR = void 0;
const axios_1 = require("axios");
const baseUrl = 'https://api.iex.cloud/v1/data/core/quote/';
const getBDR = (symbol) => axios_1.default
    .get(baseUrl + symbol + '?token=pk_7faf4690545d469aa5872f7d84d9f10c')
    .then(({ data }) => (data && data.length > 0 ? data[0] : data));
exports.getBDR = getBDR;
//# sourceMappingURL=iex.api.js.map