"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationModule = void 0;
const adapter_out_module_1 = require("@adapterOut/adapter.out.module");
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const enums_1 = require("domain/enums");
const jwt_strategy_1 = require("./jwt/jwt.strategy");
const service_1 = require("./service");
const auth_service_1 = require("./service/auth.service");
const jwt_1 = require("@nestjs/jwt");
const accountServiceProvider = {
    provide: enums_1.Providers.I_ACCOUNT_SERVICE,
    useClass: service_1.WalletService,
};
const googleServiceProvider = {
    provide: enums_1.Providers.I_GOOGLE_SERVICE,
    useClass: service_1.GoogleService,
};
const authServiceProvider = {
    provide: enums_1.Providers.I_AUTH_SERVICE,
    useClass: auth_service_1.AuthService,
};
const userServiceProvider = {
    provide: enums_1.Providers.I_USER_SERVICE,
    useClass: service_1.UserService,
};
let ApplicationModule = class ApplicationModule {
};
ApplicationModule = __decorate([
    (0, common_1.Module)({
        imports: [
            adapter_out_module_1.AdapterOutModule,
            passport_1.PassportModule.register({ defaultStrategy: 'jwt' }),
            jwt_1.JwtModule.register({
                secret: `${process.env.JWT_SECRET}`,
                signOptions: { expiresIn: '36000s' },
            }),
        ],
        providers: [
            accountServiceProvider,
            googleServiceProvider,
            jwt_strategy_1.JwtStrategy,
            authServiceProvider,
            userServiceProvider,
        ],
        exports: [
            accountServiceProvider,
            googleServiceProvider,
            jwt_strategy_1.JwtStrategy,
            authServiceProvider,
            userServiceProvider,
        ],
    })
], ApplicationModule);
exports.ApplicationModule = ApplicationModule;
//# sourceMappingURL=application.module.js.map