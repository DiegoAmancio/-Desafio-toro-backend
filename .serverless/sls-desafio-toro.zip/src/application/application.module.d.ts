export declare class ApplicationModule {
}
