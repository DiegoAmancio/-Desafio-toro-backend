"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Providers = void 0;
var Providers;
(function (Providers) {
    Providers["I_USER_SERVICE"] = "I_USER_SERVICE";
    Providers["I_USER_REPOSITORY"] = "I_USER_REPOSITORY";
    Providers["I_ACCOUNT_REPOSITORY"] = "I_ACCOUNT_REPOSITORY";
    Providers["I_ACCOUNT_SERVICE"] = "I_ACCOUNT_SERVICE";
    Providers["I_STOCKS_SERVICE"] = "I_STOCKS_SERVICE";
    Providers["I_GOOGLE_SERVICE"] = "I_GOOGLE_SERVICE";
    Providers["I_AUTH_SERVICE"] = "I_AUTH_SERVICE";
})(Providers = exports.Providers || (exports.Providers = {}));
//# sourceMappingURL=providers.enum.js.map