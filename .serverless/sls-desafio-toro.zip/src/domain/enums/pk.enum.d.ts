export declare enum PK {
    WALLET = "WALLET",
    USER = "USER"
}
