"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PK = void 0;
var PK;
(function (PK) {
    PK["WALLET"] = "WALLET";
    PK["USER"] = "USER";
})(PK = exports.PK || (exports.PK = {}));
//# sourceMappingURL=pk.enum.js.map