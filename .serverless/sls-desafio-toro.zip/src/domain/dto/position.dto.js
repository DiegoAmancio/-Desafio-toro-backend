"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PositionDTO = void 0;
class PositionDTO {
    constructor(symbol, amount, currentPrice) {
        this.symbol = symbol;
        this.amount = amount;
        this.currentPrice = currentPrice;
    }
}
exports.PositionDTO = PositionDTO;
//# sourceMappingURL=position.dto.js.map