export declare class OrderPositionDTO {
    amount: number;
    symbol: string;
}
