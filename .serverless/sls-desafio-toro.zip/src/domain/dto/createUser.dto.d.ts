export type CreateUserDTO = {
    id: string;
    email: string;
    name: string;
};
