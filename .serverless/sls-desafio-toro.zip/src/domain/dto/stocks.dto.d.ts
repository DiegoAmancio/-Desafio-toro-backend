export declare class StocksDTO {
    currentPrice: number;
    symbol: string;
    constructor(symbol: string, currentPrice: number);
}
