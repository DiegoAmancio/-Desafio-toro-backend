export declare class PositionDTO {
    symbol: string;
    amount: number;
    currentPrice: number;
    constructor(symbol: string, amount: number, currentPrice: number);
}
