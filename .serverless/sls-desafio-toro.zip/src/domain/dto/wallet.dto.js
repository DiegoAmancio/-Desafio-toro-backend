"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WalletDTO = void 0;
class WalletDTO {
    constructor(checkingAccountAmount = 0, positions = []) {
        this.checkingAccountAmount = checkingAccountAmount;
        this.positions = positions;
        this.calculateConsolidated();
    }
    calculateConsolidated() {
        this.consolidated =
            this.checkingAccountAmount +
                this.positions.reduce((count, { amount, currentPrice }) => count + amount * currentPrice, 0);
    }
}
exports.WalletDTO = WalletDTO;
//# sourceMappingURL=wallet.dto.js.map