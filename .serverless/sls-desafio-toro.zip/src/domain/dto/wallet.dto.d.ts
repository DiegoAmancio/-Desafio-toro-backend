import { PositionDTO } from './position.dto';
export declare class WalletDTO {
    checkingAccountAmount: number;
    positions: PositionDTO[];
    consolidated: number;
    constructor(checkingAccountAmount?: number, positions?: any[]);
    private calculateConsolidated;
}
