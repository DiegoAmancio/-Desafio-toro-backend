"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StocksDTO = void 0;
class StocksDTO {
    constructor(symbol, currentPrice) {
        this.currentPrice = currentPrice;
        this.symbol = symbol;
    }
}
exports.StocksDTO = StocksDTO;
//# sourceMappingURL=stocks.dto.js.map