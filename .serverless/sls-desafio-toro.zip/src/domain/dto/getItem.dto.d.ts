export type GetItemDTO = {
    PK?: string;
    SK?: string;
};
