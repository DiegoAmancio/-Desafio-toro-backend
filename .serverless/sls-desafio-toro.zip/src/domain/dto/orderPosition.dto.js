"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderPositionDTO = void 0;
class OrderPositionDTO {
}
exports.OrderPositionDTO = OrderPositionDTO;
//# sourceMappingURL=orderPosition.dto.js.map